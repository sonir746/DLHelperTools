from setuptools import setup
import os

setup(name="dlhelpertools",
      version="0.1.0",
      packages=["dlhelpertools"],
      install_requires=["numpy","opencv-python"],
      keywords=["python","image padding","padding"]
      )